import React, {useEffect} from 'react'
import Header from '../components/Header'
import DateFilter from '../components/DateFilter'
import TransmittalTable from '../components/TransmittalTable'

const Dashboard = () => {
useEffect(() => {
    const form = document.getElementById('createForm')
    const handleSubmit = async (e) => {
        e.preventDefault()

        const formData = new FormData(form)
        const newData = {
            jobNumber: formData.get('jobNumber'),
            title: formData.get('transNo'), // kalau transNo = title
            date: formData.get('date1'),    // pilih date1 atau date2
            sender: formData.get('sender'),
            recipient: formData.get('receiver'), // receiver jadi recipient
        }

        const res = await fetch('http://localhost:5069/api/transmittal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newData),
        })

        if (res.ok) {
            form.reset()
            document.querySelector('#createModal .btn-close')?.click()
            window.location.reload()
        } else {
            alert('Failed to save data')
        }
    }

    form?.addEventListener('submit', handleSubmit)

    return () => {
        form?.removeEventListener('submit', handleSubmit)
    }
}, [])


    return (
        <div className="p-3">
            <Header />
            <DateFilter />
            <button className="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#createModal">+ Add Transmittal</button>
            <div className="modal fade" id="createModal" tabIndex="-1">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Add Transmittal</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div className="modal-body">
                            <form id="createForm">
                                <div className="mb-2">
                                    <label className="form-label">Trans No</label>
                                    <input type="text" className="form-control" name="transNo" required />
                                </div>
                                <div className="mb-2">
                                    <label className="form-label">Job Number</label>
                                    <input type="text" className="form-control" name="jobNumber" required />
                                </div>
                                <div className="mb-2">
                                    <label className="form-label">Date 1</label>
                                    <input type="date" className="form-control" name="date1" required />
                                </div>
                                <div className="mb-2">
                                    <label className="form-label">Date 2</label>
                                    <input type="date" className="form-control" name="date2" required />
                                </div>
                                <div className="mb-2">
                                    <label className="form-label">Sender</label>
                                    <input type="text" className="form-control" name="sender" required />
                                </div>
                                <div className="mb-2">
                                    <label className="form-label">Receiver</label>
                                    <input type="text" className="form-control" name="receiver" />
                                </div>
                            </form>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" form="createForm" className="btn btn-primary">Save</button>
                        </div>
                    </div>
                </div>
            </div>
            <TransmittalTable />
        </div>
    )
}

export default Dashboard