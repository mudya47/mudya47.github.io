import React, { useEffect, useState } from 'react'
import { FileEarmark } from 'react-bootstrap-icons'

const TransmittalTable = () => {
  const [data, setData] = useState([])

  useEffect(() => {
    fetch('http://localhost:5069/api/transmittal') // GANTI PORT dgn yang ASP.NET pakai
      .then((res) => res.json())
      .then((result) => setData(result))
      .catch((err) => console.error('Error fetching:', err))
  }, [])

  return (
    <div className="table-responsive">
      <table className="table table-bordered table-hover">
        <thead className="table-light">
          <tr>
            <th>Trans-No</th>
            <th>Job Number</th>
            <th>Date</th>
            <th>Date</th>
            <th>Sender</th>
            <th>Receiver</th>
            <th>Form Attachment</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              <td>{item.transNo}</td>
              <td>{item.jobNumber}</td>
              <td>{item.date1 ? new Date(item.date1).toLocaleDateString('en-GB') : ''}</td>
              <td>{item.date2 ? new Date(item.date2).toLocaleDateString('en-GB') : ''}</td>
              <td>{item.sender}</td>
              <td>{item.receiver}</td>
              <td className="text-center"><FileEarmark /></td>
              <td><button className="btn btn-sm btn-outline-primary">Edit</button></td>
              <td><button className="btn btn-sm btn-outline-danger">Delete</button></td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="d-flex justify-content-center my-3 gap-2">
        <button className="btn btn-outline-secondary btn-sm">Previous</button>
        <button className="btn btn-outline-secondary btn-sm">Next</button>
      </div>
    </div>
  )
}

export default TransmittalTable