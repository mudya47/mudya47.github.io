namespace TransmittalTrackerAPI.Models
{
    public class Transmittal
    {
        public int Id { get; set; }
        public string TransNo { get; set; } = string.Empty;
        public required string JobNumber { get; set; }
        public required string Title { get; set; }
        public required DateTime Date { get; set; }
        public required string Sender { get; set; }
        public required string Recipient { get; set; }
    }
}