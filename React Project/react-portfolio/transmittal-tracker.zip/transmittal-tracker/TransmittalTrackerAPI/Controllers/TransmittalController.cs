using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TransmittalTrackerAPI.Data;
using TransmittalTrackerAPI.Models;

namespace TransmittalTrackerAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransmittalController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TransmittalController(AppDbContext context)
        {
            _context = context;
        }

        // 📘 GET ALL
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var data = await _context.Transmittals.ToListAsync();
            return Ok(data);
        }

        // 📘 GET BY ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var trans = await _context.Transmittals.FindAsync(id);
            if (trans == null)
                return NotFound();

            return Ok(trans);
        }

        // 🟢 CREATE
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Transmittal newTrans)
        {
            if (newTrans == null)
                return BadRequest();

            _context.Transmittals.Add(newTrans);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = newTrans.Id }, newTrans);
        }

        // 🟡 UPDATE
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Transmittal updatedTrans)
        {
            if (id != updatedTrans.Id)
                return BadRequest("ID mismatch");

            var existing = await _context.Transmittals.FindAsync(id);
            if (existing == null)
                return NotFound();

            // update properti satu per satu
            existing.JobNumber = updatedTrans.JobNumber;
            existing.Title = updatedTrans.Title;
            existing.Date = updatedTrans.Date;
            existing.Sender = updatedTrans.Sender;
            existing.Recipient = updatedTrans.Recipient;

            await _context.SaveChangesAsync();
            return Ok(existing);
        }

        // 🔴 DELETE
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var trans = await _context.Transmittals.FindAsync(id);
            if (trans == null)
                return NotFound();

            _context.Transmittals.Remove(trans);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Deleted successfully" });
        }
    }
}